#DEVI AGGIUSTARE LO YES INTENT; PERCHE' CAN HANDLE GLI DICE CHE NON DEVE ATTIVARSI LO YES INTENT, CORREGGI!!!!!!!!!!!!!!!!!!!!!!
# -*- coding: utf-8 -*-

# This is a High Low Guess game Alexa Skill.
# The skill serves as a simple sample on how to use the
# persistence attributes and persistence adapter features in the SDK.
import random
import logging
import os
import boto3

from ask_sdk_core.skill_builder import CustomSkillBuilder
from ask_sdk_core.utils import is_request_type, is_intent_name
from ask_sdk_core.handler_input import HandlerInput


from ask_sdk_model import Response
from ask_sdk_dynamodb.adapter import DynamoDbAdapter

SKILL_NAME = 'become a psychologist'
ddb_region = os.environ.get('DYNAMODB_PERSISTENCE_REGION')
ddb_table_name = os.environ.get('DYNAMODB_PERSISTENCE_TABLE_NAME')
ddb_resource = boto3.resource('dynamodb', region_name=ddb_region)
dynamodb_adapter = DynamoDbAdapter(table_name=ddb_table_name, create_table=False, dynamodb_resource=ddb_resource)
sb = CustomSkillBuilder(persistence_adapter=dynamodb_adapter)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

#####################################################################################################################################################################################################
##################################################################################LOGICA DEL GIOCO###################################################################################################
#####################################################################################################################################################################################################


#classe paziente
class patient:
    def __init__(self, name, gender, age, stress, state, trust, family, work, love, friendship, tpresponse):
        self.name = name
        self.gender = gender
        self.age = age
        self.stress = stress
        self.state = state
        self.trust = trust
        self.family = family
        self.work = work
        self.love = love
        self.friendship = friendship
        self.tpresponse = tpresponse



#classe per la visita in corso
class curr_visit():
    def __init__(self, stage, tp, md, cs, ct, tpold, currentmessage, agmod, choise,firstvisit,topicbonusmalus, stressbonusmalus, trustbonusmalus, theme, motivation,changetopic,doc_reply):
        self.stage = stage
        self.tp = tp
        self.md = md
        self.cs = cs
        self.ct = ct
        self.tpold = tpold
        self.currentmessage = currentmessage
        self.agmod = agmod
        self.choise = choise
        self.firstvisit = firstvisit
        self.topicbonusmalus = topicbonusmalus
        self.stressbonusmalus = stressbonusmalus
        self.trustbonusmalus = trustbonusmalus
        self.theme = theme
        self.motivation = motivation
        self.changetopic = changetopic
        self.doc_reply = doc_reply
    
#generatore pazienti
def genpatient():
    names = ["Nik", "Abe", "Sel", "Kuk", "Guy"]
    name = random.choice(names)
    gender = "Male"#aggiusta deve essere random tra maschio e femmina
    age = str(random.randint(7, 100))
    stress = random.randint(0,10)
    state = ""
    trust = random.randint(0,10)
    family = random.randint(0,10)
    work = random.randint(0,10)
    love = random.randint(0,10)
    friendship = random.randint(0,10)
    tpresponse = ""
    return patient(name,gender,age,stress,state,trust,family,work, love,friendship, tpresponse)




###########################################################################################################
####################VARIABILI SETTATE 1 TIME ALL'INIZIO DI OGNI NUOVA VISITA###############################
###########################################################################################################
currentvisit = curr_visit(0,"fm","ag", 0, 0,"","",0,"", True, 0, 0, 0, "", "","","")
curr_patient = patient(0,0,0,0,0,0,0,0,0,0,0)
#Lista per salvare le info sul paziente tra una visita e l'altra
###########################################################################################################
#########################################LOGICA DI GIOCO###################################################
###########################################################################################################

def startvisit():
    curr_topic = {curr_patient.family:"my family",curr_patient.work:"my job",curr_patient.love:"my partner", curr_patient.friendship:"my friends"}
    topic = curr_topic.get(max(curr_topic))
    topicvalue = max(curr_patient.family, curr_patient.work, curr_patient.love, curr_patient.friendship)
    if (curr_patient.stress + curr_patient.trust) / 2 > 8 and topicvalue > 7:
        initialtopic = (random.choice(an) + ", " + topic)
        currentvisit.firstvisit = "false"
    elif (curr_patient.stress + curr_patient.trust) / 2 > 8 and topicvalue < 3:
        initialtopic = (random.choice(ap) + ", " + topic)
        currentvisit.firstvisit = "false"
    elif (curr_patient.stress + curr_patient.trust) / 2 < 3 and topicvalue > 7:
        initialtopic = (random.choice(nv) + ", " + topic)
        currentvisit.firstvisit = "false"
    elif (curr_patient.stress + curr_patient.trust) / 2 < 3 and topicvalue < 3:
        initialtopic = (random.choice(tr) + ", " + topic)
        currentvisit.firstvisit = "false"
    else:
        initialtopic = (random.choice(norm) + ", " + topic)
        currentvisit.firstvisit = "false"
    return initialtopic


def opening():
    global curr_patient
    curr_patient = genpatient()
    openingphrase = ("Ok, here is your new patient" + "\nName " + curr_patient.name + ", It's a " + curr_patient.gender + ", " + curr_patient.age + " years old, stress level of " + str(
                curr_patient.stress) + " and a trust level of " + str(curr_patient.trust)
                      + "\nThe patients greets you says\n" + startvisit())
    return openingphrase


def START_calculate_stresstrust_changes(approach):
    currentvisit.currentmessage = ""  #reset the phrase at beginning of each round
    if approach == "ag":
        currentvisit.cs = 0
        currentvisit.ct = 0
        currentvisit.cs += (1 + random.randint(0, 1))
        currentvisit.ct -= (1 + random.randint(0, 1))
        currentvisit.choise = random.choice(aggre)
    elif approach == "lo":
        currentvisit.cs = 0
        currentvisit.ct = 0
        currentvisit.cs -= (1 + random.randint(0, 1))
        currentvisit.ct -= (1 + random.randint(0, 1))
        currentvisit.choise = random.choice(logic)
    elif approach == "dr":
        currentvisit.cs = 0
        currentvisit.ct = 0
        currentvisit.cs += (1 + random.randint(0, 1))
        currentvisit.ct += (1 + random.randint(0, 1))
        currentvisit.choise = random.choice(direc)
    elif approach == "po":
        currentvisit.cs = 0
        currentvisit.ct = 0
        currentvisit.cs -= (1 + random.randint(0, 1))
        currentvisit.ct += (1 + random.randint(0, 1))
        currentvisit.choise = random.choice(posit)
    topicchange()



def topicchange():
    currentvisit.changetopic = ""
    if currentvisit.firstvisit:
        currentvisit.firstvisit = False
    elif currentvisit.tpold != currentvisit.tp:
        currentvisit.changetopic = "You respond: Ok, but now I would like to talk about something else"
        currentvisit.tpold = currentvisit.tp
    else:
        currentvisit.tpold = currentvisit.tp
    agegendermod()

# funzione per aggiungere modifiers per età e sesso del paziente
def agegendermod():
    currentvisit.agmod = 0
    page = curr_patient.age
    if curr_patient.gender == "Male" and 0 < int(page) < 25:
        if currentvisit.md == "ag":
            currentvisit.agmod -= 3
        elif currentvisit.md == "dr":
            currentvisit.agmod -= 2
        elif currentvisit.md == "po":
            currentvisit.agmod += 0
        elif currentvisit.md == "lo":
            currentvisit.agmod += 1
    elif curr_patient.gender == "Male" and 25 < int(page) < 65:
        if currentvisit.md == "ag":
            currentvisit.agmod -= 1
        elif currentvisit.md == "dr":
            currentvisit.agmod += 3
        elif currentvisit.md == "po":
            currentvisit.agmod -= 1
        elif currentvisit.md == "lo":
            currentvisit.agmod -= 3
    elif curr_patient.gender == "Male" and 65 < int(page) < 100:
        if currentvisit.md == "ag":
            currentvisit.agmod += 3
        elif currentvisit.md == "dr":
            currentvisit.agmod += 3
        elif currentvisit.md == "po":
            currentvisit.agmod -= 3
        elif currentvisit.md == "lo":
            currentvisit.agmod += 2
    elif curr_patient.gender == "Female" and 0 < int(page) < 25:
        if currentvisit.md == "ag":
            currentvisit.agmod += 3
        elif currentvisit.md == "dr":
            currentvisit.agmod += 0
        elif currentvisit.md == "po":
            currentvisit.agmod -= 3
        elif currentvisit.md == "lo":
            currentvisit.agmod -= 1
    elif curr_patient.gender == "Female" and 25 < int(page) < 65:
        if currentvisit.md == "ag":
            currentvisit.agmod += 2
        elif currentvisit.md == "dr":
            currentvisit.agmod += 2
        elif currentvisit.md == "po":
            currentvisit.agmod -= 2
        elif currentvisit.md == "lo":
            currentvisit.agmod -= 3
    elif curr_patient.gender == "Female" and 65 < int(page) < 100:
        if currentvisit.md == "ag":
            currentvisit.agmod += 3
        elif currentvisit.md == "dr":
            currentvisit.agmod -= 1
        elif currentvisit.md == "po":
            currentvisit.agmod -= 3
        elif currentvisit.md == "lo":
            currentvisit.agmod += 3
    new_values_StressTrustTopic()
    
    

def new_values_StressTrustTopic():
    currentvisit.doc_reply = ""
    currentvisit.tpbonusmalus = 0
    if currentvisit.tp == "fm":
        currentvisit.tpbonusmalus = (currentvisit.ct + currentvisit.cs + currentvisit.agmod)#questa formula è da rivedere, questa determina quanto sale o scende il topic, quindi cambiala, magari anche in base al topic
        curr_patient.family += (currentvisit.tpbonusmalus+currentvisit.topicbonusmalus)
        curr_patient.stress += currentvisit.cs
        curr_patient.trust += currentvisit.ct
        currentvisit.doc_reply =  (currentvisit.choise + ", " + random.choice(famy))
    elif currentvisit.tp == "wr":
        currentvisit.tpbonusmalus = (currentvisit.cs + currentvisit.ct + currentvisit.agmod)
        curr_patient.work += (currentvisit.tpbonusmalus+currentvisit.topicbonusmalus)
        curr_patient.stress += currentvisit.cs
        curr_patient.trust += currentvisit.ct
        currentvisit.doc_reply =  (currentvisit.choise + ", " + random.choice(worki))
    elif currentvisit.tp == "fr":
        currentvisit.tpbonusmalus = (currentvisit.cs + currentvisit.ct + currentvisit.agmod)
        curr_patient.friendship += (currentvisit.tpbonusmalus+currentvisit.topicbonusmalus)
        curr_patient.stress += currentvisit.cs
        curr_patient.trust += currentvisit.ct
        currentvisit.doc_reply =  (currentvisit.choise + ", " + random.choice(friends))
    elif currentvisit.tp == "lv":
        currentvisit.tpbonusmalus = (currentvisit.cs + currentvisit.ct + currentvisit.agmod)
        curr_patient.love += (currentvisit.tpbonusmalus+currentvisit.topicbonusmalus)
        curr_patient.stress += currentvisit.cs
        curr_patient.trust += currentvisit.ct
        currentvisit.doc_reply =  (currentvisit.choise + ", " + random.choice(loves))
    checktopicstatus()



# fa finire la visita se i topic si sballano
def checktopicstatus():
    topicsforendsession = {curr_patient.family: "family", curr_patient.work: "job", curr_patient.love: "love and partners",
                           curr_patient.friendship: "friends"}
    if curr_patient.family < -25 or curr_patient.work < -25 or curr_patient.friendship < -25 or curr_patient.love < -25:
        currentvisit.currentmessage = (
                    "Good news doctor! You have untangled the issued of the patient on the topic of " + topicsforendsession.get(
                min(topicsforendsession)))
    elif curr_patient.family > 25 or curr_patient.work > 25 or curr_patient.friendship > 25 or curr_patient.love > 25:
        currentvisit.currentmessage = (
                    "Bad news doctor! you have disappointed  the patient on the topic of " + topicsforendsession.get(
                max(topicsforendsession)) + ", and he won't be your patient anymore")
    themesadder()
    
    

def themesadder():
    currentvisit.theme = ""
    currentvisit.motivation = ""
    #IDEE per tipi di conclusione partita:
    #FIDUCIA ALTA ma topics non molto alti, semplicemente il paziente dice di sentirsi meglio
    #STRESS ALTO ma topics non molto male, semplicemente il paziente si scoccia di te
    #TOPICS ALTI(funzione precedente)
    #TOPICS BASSI(funzione precedente)
    # Aggiungi fine gioco anche sugli altri temi
    if curr_patient.stress > 10:
        currentvisit.theme = "you stressed the patient"
    else:
        currentvisit.theme = ""
    tppatientresponse()
    


def tppatientresponse():
    curr_patient.tpresponse = ""
    if currentvisit.tp == "fm":
        if -10 < curr_patient.family <= -5 or curr_patient.family <= -10:
            curr_patient.tpresponse = random.choice(vlowfamily) 
        elif -5 < curr_patient.family <= 0:
            curr_patient.tpresponse = random.choice(lowfamily)
        elif 0 < curr_patient.family <= 5:
            curr_patient.tpresponse = random.choice(highfamily)
        elif 5 < curr_patient.family <= 10 or curr_patient.family >= 10:
            curr_patient.tpresponse = random.choice(vhighfamily)
    elif currentvisit.tp == "lv":
        if -10 < curr_patient.love <= -5 or curr_patient.love <= -10:
            curr_patient.tpresponse = random.choice(vlowlove)
        elif -5 < curr_patient.love <= 0:
            curr_patient.tpresponse = random.choice(lowlove)
        elif 0 < curr_patient.love <= 5:
            curr_patient.tpresponse = random.choice(highlove)
        elif 5 < curr_patient.love <= 10 or curr_patient.love >= 10:
            curr_patient.tpresponse = random.choice(vhighlove)
    elif currentvisit.tp == "fr":
        if -10 < curr_patient.friendship <= -5 or curr_patient.friendship <= -10:
            curr_patient.tpresponse = random.choice(vlowrelations)
        elif -5 < curr_patient.friendship <= 0:
            curr_patient.tpresponse = random.choice(lorelations)
        elif 0 < curr_patient.friendship <= 5:
            curr_patient.tpresponse = random.choice(highrelations)
        elif 5 < curr_patient.friendship <= 10 or curr_patient.friendship >= 10:
            curr_patient.tpresponse = random.choice(vhighrelations)
    elif currentvisit.tp == "wr":
        if -10 < curr_patient.work <= -5 or curr_patient.work <= -10:
            curr_patient.tpresponse = random.choice(vlowsuccess)
        elif -5 < curr_patient.work <= 0:
            curr_patient.tpresponse = random.choice(losuccess)
        elif 0 < curr_patient.work <= 5:
            curr_patient.tpresponse = random.choice(highsuccess)
        elif 5 < curr_patient.work <= 10 or curr_patient.work >= 10:
            curr_patient.tpresponse = random.choice(vhighsuccess)
    patientreply()
    

# Funzione per la risposta del paziente, questa cura solo la parte relativa a come stress e trust sono cambiati in base alla risposta del paziente
def patientreply():
    if -5 < curr_patient.stress < 5 or curr_patient.stress < -5:
        stress_description = random.choice(lowstress)
    elif 5 < curr_patient.stress < 10:
        stress_description = random.choice(avgstress)
    elif 10 < curr_patient.stress < 15 or curr_patient.stress > 15:
        stress_description = random.choice(highstress)
    else:
        stress_description = ""
    if -5 < curr_patient.trust < 5 or curr_patient.trust < -5:
        trust_description = random.choice(lowtrust)
    elif 5 < curr_patient.trust < 10:
        trust_description = random.choice(avgtrust)
    elif 10 < curr_patient.trust < 15 or curr_patient.trust > 15:
        trust_description = random.choice(hightrust)
    else:
        trust_description = ""
    final_reply = currentvisit.changetopic + ", "+ currentvisit.doc_reply + ", "+ trust_description +", " +stress_description +", " + curr_patient.tpresponse
    currentvisit.currentmessage = final_reply


#####################################################################################################################################################################################################
##################################################################################LOGICA DI ALEXA###################################################################################################
#####################################################################################################################################################################################################



@sb.request_handler(can_handle_func=is_request_type("LaunchRequest"))
def launch_request_handler(handler_input):
    """Handler for Skill Launch.

    Get the persistence attributes, to figure out the game state.
    """
    # type: (HandlerInput) -> Response
    attr = handler_input.attributes_manager.persistent_attributes
    if not attr:
        attr['cured_patients'] = 0
        attr['game_state'] = 'ENDED'
        attr['currently_visiting'] = "firsttime"
    
    
    attr['game_state'] = 'ENDED' #DEVI RESETTARE LO STATO AD OGNI LANCIO DEL GIOCO SENNO' SBALLI GLI STATES
    handler_input.attributes_manager.session_attributes = attr
    handler_input.attributes_manager.save_persistent_attributes()
    
    
    if attr['currently_visiting'] == "firsttime":
        speech_text = "Welcome to your office doctor. You can cure your patient by talking to them. You can choose between four topics: Family, Friends, Love and Work and you can use four approaches, Aggressive, Logic, Positive and direct. Would you like to visit your first patient?"
        reprompt = "Say yes to start a session or no to quit."
        attr['currently_visiting'] = "notfirsttime"
    elif attr['currently_visiting'] == "patientinprogress":
        #load persistent attributed of the patient from dynamodb
        curr_patient.name = attr['patient_save_slot'][0]
        curr_patient.gender = attr['patient_save_slot'][1]
        curr_patient.age = attr['patient_save_slot'][2]
        curr_patient.stress = attr['patient_save_slot'][3]
        curr_patient.state = attr['patient_save_slot'][4]
        curr_patient.trust = attr['patient_save_slot'][5]
        curr_patient.family = attr['patient_save_slot'][6]
        curr_patient.work = attr['patient_save_slot'][7]
        curr_patient.love = attr['patient_save_slot'][8]
        curr_patient.friendship = attr['patient_save_slot'][9]
        curr_patient.tpresponse = attr['patient_save_slot'][10]
        currentvisit.tpold = attr['patient_save_slot'][11]
        
        speech_text = "you were visiting a patient named {}, Would you like to continue your visit?".format(curr_patient.name)
        reprompt = "Say yes to continue the visit or no to close the game"
    else:
        speech_text = "Welcome back to your office, doctor. You have cured {} patients. Would you like to visit another patient?".format(attr["cured_patients"])
        reprompt = "Say yes to continue the visit or no to close the game"
    
    handler_input.attributes_manager.session_attributes = attr
    handler_input.attributes_manager.save_persistent_attributes()
    
    handler_input.response_builder.speak(speech_text).ask(reprompt)
    return handler_input.response_builder.response


@sb.request_handler(can_handle_func=is_intent_name("AMAZON.HelpIntent"))
def help_intent_handler(handler_input):
    """Handler for Help Intent."""
    # type: (HandlerInput) -> Response
    speech_text = (
        "I am thinking of a number between zero and one hundred, try to "
        "guess it and I will tell you if you got it or it is higher or "
        "lower")
    reprompt = "Try saying a number."

    handler_input.response_builder.speak(speech_text).ask(reprompt)
    return handler_input.response_builder.response


@sb.request_handler(
    can_handle_func=lambda input:
        is_intent_name("AMAZON.CancelIntent")(input) or
        is_intent_name("AMAZON.StopIntent")(input))
def cancel_and_stop_intent_handler(handler_input):
    """Single handler for Cancel and Stop Intent."""
    # type: (HandlerInput) -> Response
    speech_text = "Thanks for playing!!"

    handler_input.response_builder.speak(
        speech_text).set_should_end_session(True)
    return handler_input.response_builder.response


@sb.request_handler(can_handle_func=is_request_type("SessionEndedRequest"))
def session_ended_request_handler(handler_input):
    """Handler for Session End."""
    # type: (HandlerInput) -> Response
    logger.info(
        "Session ended with reason: {}".format(
            handler_input.request_envelope.request.reason))
    return handler_input.response_builder.response


def currently_playing(handler_input):
    """Function that acts as can handle for game state."""
    # type: (HandlerInput) -> bool
    is_currently_playing = False
    session_attr = handler_input.attributes_manager.session_attributes

    if ("game_state" in session_attr
            and session_attr['game_state'] == "STARTED"):
        is_currently_playing = True

    return is_currently_playing


@sb.request_handler(can_handle_func=lambda input:
                    not currently_playing(input) and
                    is_intent_name("AMAZON.YesIntent")(input))
def yes_handler(handler_input):
    """Handler for Yes Intent, only if the player said yes for
    a new game.
    """
    # type: (HandlerInput) -> Response
    session_attr = handler_input.attributes_manager.session_attributes
    session_attr['game_state'] = "STARTED"


    if session_attr['currently_visiting'] == "patientinprogress":
        speech_text = "ok last time you were talking about {}, choose topic and approach".format(currentvisit.tpold)
        reprompt = "Choose topic and approach for your reply"
    else:
        speech_text = opening()
        reprompt = "CHOOSE APPROACH AND TOPIC"
    
    session_attr['patient_save_slot'] = [curr_patient.name, curr_patient.gender, curr_patient.age, curr_patient.stress,
               curr_patient.state, curr_patient.trust,
               curr_patient.family, curr_patient.work, curr_patient.love,
               curr_patient.friendship, curr_patient.tpresponse, currentvisit.tp]
    session_attr['currently_visiting'] = "patientinprogress"    
    
    handler_input.attributes_manager.persistent_attributes = session_attr
    handler_input.attributes_manager.save_persistent_attributes()
    

    handler_input.response_builder.speak(speech_text).ask(reprompt)
    return handler_input.response_builder.response


@sb.request_handler(can_handle_func=lambda input:
                    not currently_playing(input) and
                    is_intent_name("AMAZON.NoIntent")(input))
def no_handler(handler_input):
    """Handler for No Intent, only if the player said no for
    a new game.
    """
    # type: (HandlerInput) -> Response
    session_attr = handler_input.attributes_manager.session_attributes
    session_attr['game_state'] = "ENDED"

    handler_input.attributes_manager.persistent_attributes = session_attr
    handler_input.attributes_manager.save_persistent_attributes()

    speech_text = "Ok. See you next time!!"

    handler_input.response_builder.speak(speech_text)
    return handler_input.response_builder.response


@sb.request_handler(can_handle_func=lambda input:
                    currently_playing(input) and
                    is_intent_name("topic_approach")(input))
def number_guess_handler(handler_input):
    #Handler for processing approach and topic choosen by player.
    # type: (HandlerInput) -> Response
    session_attr = handler_input.attributes_manager.session_attributes
    
    #Getting the slots ID from the intent
    topic_intent = handler_input.request_envelope.request.intent.slots[
        "topic"].resolutions.resolutions_per_authority[0].values[0].value.id
        
    approach_intent = handler_input.request_envelope.request.intent.slots[
        "approach"].resolutions.resolutions_per_authority[0].values[0].value.id
    
    
    currentvisit.md = approach_intent
    currentvisit.tp = topic_intent
    START_calculate_stresstrust_changes(approach_intent)

    if currentvisit.theme == "": #quando la visita non è ancora conclusa quindi non c'è un tema
        speech_text = currentvisit.currentmessage
        reprompt = "Choose the topic and approach for your reply to the patient"
        session_attr['currently_visiting'] = "patientinprogress"
        session_attr['patient_save_slot'] = [curr_patient.name, curr_patient.gender, curr_patient.age, curr_patient.stress,
               curr_patient.state, curr_patient.trust,
               curr_patient.family, curr_patient.work, curr_patient.love,
               curr_patient.friendship, curr_patient.tpresponse, currentvisit.tp]
    else:
        speech_text = currentvisit.theme + "Ok so you have lost your patient, would you like to visit a new patient?"
        reprompt = "Wanna try a new patient?"
        ######set attributes#####
        session_attr['game_state'] = "ENDED"
        session_attr['currently_visiting'] = "notfirsttime"
        session_attr['cured_patients'] +=1
        session_attr['patient_save_slot'] = [0,0,0,0,0,0,0,0,0,0,0]
        
    
    
    handler_input.attributes_manager.persistent_attributes = session_attr
    handler_input.attributes_manager.save_persistent_attributes()

    handler_input.response_builder.speak(speech_text).ask(reprompt)
    return handler_input.response_builder.response


@sb.request_handler(can_handle_func=lambda input:
                    is_intent_name("AMAZON.FallbackIntent")(input) or
                    is_intent_name("AMAZON.YesIntent")(input) or
                    is_intent_name("AMAZON.NoIntent")(input))
def fallback_handler(handler_input):
    #AMAZON.FallbackIntent is only available in en-US locale.
    #This handler will not be triggered except in that locale,
    #so it is safe to deploy on any locale.
    
    # type: (HandlerInput) -> Response
    session_attr = handler_input.attributes_manager.session_attributes

    if ("game_state" in session_attr and
            session_attr["game_state"]=="STARTED"):
        speech_text = (
            "The {} skill can't help you with that.  "
            "Choose a topic between family, friends, work and love and an approach between logic, direct, aggressive and positive".format(SKILL_NAME))
        reprompt = "Choose approach and topic"
    else:
        speech_text = (
            "The {} skill can't help you with that.  "
            "It will come up with a number between 0 and 100 and "
            "you try to guess it by saying a number in that range. "
            "Would you like to play?".format(SKILL_NAME))
        reprompt = "Say yes to start the game or no to quit."

    handler_input.response_builder.speak(speech_text).ask(reprompt)
    return handler_input.response_builder.response


@sb.request_handler(can_handle_func=lambda input: True)
def unhandled_intent_handler(handler_input):
    """Handler for all other unhandled requests."""
    # type: (HandlerInput) -> Response
    speech = "Say yes to continue or no to end the game!!"
    handler_input.response_builder.speak(speech).ask(speech)
    return handler_input.response_builder.response


@sb.exception_handler(can_handle_func=lambda i, e: True)
def all_exception_handler(handler_input, exception):
    """Catch all exception handler, log exception and
    respond with custom message.
    """
    # type: (HandlerInput, Exception) -> Response
    logger.error(exception, exc_info=True)
    speech = "Sorry, I can't understand that. Please say again!!"
    handler_input.response_builder.speak(speech).ask(speech)
    return handler_input.response_builder.response


@sb.global_response_interceptor()
def log_response(handler_input, response):
    """Response logger."""
    # type: (HandlerInput, Response) -> None
    logger.info("Response: {}".format(response))



lambda_handler = sb.lambda_handler()

####liste delle frasi iniziali per introdurre la visita:
norm = ["I was thinking about", "I would like to talk about"]
an = ["It makes me angry", "I hate this"]
nv = ["it's driving me crazy!", "Fuck everything!"]
tr = ["Dear doctor, finally I can talk to you", "I was waiting to tell you"]
ap = ["I don't care, but", "Nothing to say, except maybe"]
#liste per le risposte del dottore
aggre = ["Don't be weak", "You should be ashamed", "You are disappointing me","Stop acting like this! You need to face this now"]
logic = ["Science is clear on this point", "A recent study shows", "Trust me, I' have studied",]
posit = ["Everything will be ok", "It's not that big an issue", "You are a strong individual"]
direc = ["let me be clear", "This is your problem", "The explanation is easy"]

famy = ["we need to accept family members as they are", "parents are not perfect, they are humans like us", "With family, often there are things happend in the past that have never been clarified"]
worki = ["Working environments are often stressful", "Don't confuse work with your personal life", "Work is not everything there is to life"]
friends = ["Often times we don't invest in friendships", "maybe our friends are expecting something from us", "Friends can be as important as family"]
loves = ["Sometimes we take our partner for granted", "We may argue with our partner, but it dosen't mean that love is lacking", "if there is love, everything can be overcome"]

#liste per lo status dei topic del paziente
#riscrivi gli average, devono sempre dare messaggio di positività, altrimenti non sai come interpretarli,anzi, non ci saranno averages, ci saranno due livelli di positivo e due livelli di negativo...e basta

vlowfamily = ["now that I think about it, all my good values came from my family", "I learned how to be a good person from my family", "my family thaught me inconditional love!"]
lowfamily = ["maybe Without my family I wouldn't be that good", "maybe I just did not understand that my parents really loved me", "I think I have always been too negative about my family"]
avgfamily = ["average family"]
highfamily = ["I don't know if my family was good for me or not", "maybe I could be a better person if it wasn't for my family", "did I really learned something good from my family?"]
vhighfamily = ["I guess I don't really trust my family", "maybe my family was not a good example for me", "my family has always been mean to me, after all"]

vlowlove = ["very low love"]
lowlove =["I get it now, it was just miss-understandings, my partner does really love me!", "I was just thinking about myself, now I realize I want to be a loving partner", "I finally want to re-invest all myself for my love relationship"]
avglove = ["what if my relationship is broken...I don't know...", "being in a relationship is difficult, maybe I can't handle that", "What good did I take out of my relationship?"]
highlove = ["I realize it now, my partner just wants to use me", "My relationship is toxic and I should let it go", "my partner is an egoist and it's not good for me"]
vhighlove = ["very high love"]

vlowsuccess = ["very low success (good)"]
losuccess = ["low success(good)"]
avgsuccess = ["average success"]
highsuccess = ["high success(bad)"]
vhighsuccess = ["very high success(Bad)"]

vlowrelations = ["very low relations (good)"]
lorelations = ["low relations(good)"]
avgrelations = ["average relations"]
highrelations = ["high relations(bad)"]
vhighrelations = ["very high relations(Bad)"]

#risposte del paziente(questa parte ti informa su come è andata la tua risposta corrente
highstress = ["Hey doc, I'm already stressed out", "Wow that was rough", "Don't talk to me like that", "If you talk to me like that you'll make things worst"]
lowstress = ["thanks, this calms me down", "I'm feeling better now", "Thanks for the advise doc!"]
hightrust = ["I think you understand me", "I'm confortable talking to you", "Yes, I agree with you"]
lowtrust = ["I'm feeling a bit unconfortable", "That hurt me", "this is just a waste of money and time"]
avgstress = ["I see", "yeah it may be", "Maybe you are right"]
avgtrust = ["maybe I can trust you", "maybe you know better than me", "maybe I should listen to you"]

#aggiungere una parte della frase che invece indica in totale come sta andando lo stress e trust del paziente
# liste dei messaggi da mostrare al giocatore per la vita a casa
welcomemessage = "Welcome back home doctor. Your wife and two kids are doing all right\nYou have healthy relationships with lots of friends\nYou also must find time to study and update your knoledge in psychology\nAnd last but not least, you must take some free time to relax"

#dizionario per le reazioni stressanti(al momento feature in standby - dizionario non usato)
emotional_status_dictionary = {
    1: {
        1: "Low stress",
        2: "Moderate stress",
        3: "high stress",
    },
    2: {
        1: "Low trust",
        2: "Moderate trust",
        3: "High trust",
    },
}
